"use client"

import { useEffect, useState } from "react"
import { ArrowRight, Mic } from "lucide-react"
import { Button } from "./components/ui/button"
import { Card } from "./components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select"
import { Textarea } from "./components/ui/textarea"

export default function AudioTranslator() {
  const [sourceLanguage, setSourceLanguage] = useState("english")
  const [targetLanguage, setTargetLanguage] = useState("hindi")
  const [originalText, setOriginalText] = useState("")
  const [translatedText, setTranslatedText] = useState("")

  const handleSourceLanguageChange = (value) => {
    setSourceLanguage(value)
  }

  const handleTargetLanguageChange = (value) => {
    setTargetLanguage(value)
  }

  const handleMicClick = () => {
    // Add microphone functionality here
    console.log("Microphone clicked")
  }

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-blue-600 via-blue-500 to-purple-600 p-4">
      <Card className="w-full max-w-2xl p-8 space-y-8">
        <div className="flex items-center gap-3 mb-6">
          <Mic className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-semibold tracking-tight">Audio Translator</h1>
        </div>

        <div className="flex items-center gap-4 justify-center">
          <Select value={sourceLanguage} onValueChange={handleSourceLanguageChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="english">English</SelectItem> 
              <SelectItem value="hindi">Hindi</SelectItem> 
              <SelectItem value="french">French</SelectItem>
              <SelectItem value="german">German</SelectItem>
            </SelectContent>
          </Select>

          <ArrowRight className="w-5 h-5 text-blue-500" />

          <Select value={targetLanguage} onValueChange={handleTargetLanguageChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
            {sourceLanguage === "hindi" && <SelectItem value="english">English</SelectItem> }
            {sourceLanguage === "english" && <SelectItem value="hindi">Hindi</SelectItem> }
              <SelectItem value="tamil">Tamil</SelectItem>
              <SelectItem value="telugu">Telugu</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex justify-center my-8">
          <Button
            size="lg"
            className="w-20 h-20 rounded-full hover:scale-105 transition-transform bg-black"
            onClick={handleMicClick}
          >
            <Mic className="w-8 h-8" />
          </Button>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Mic className="w-4 h-4" />
              <span>Original:</span>
            </div>
            <Textarea
              placeholder="Your speech will appear here..."
              className="min-h-[100px] resize-none bg-muted/50"
              value={originalText}
              readOnly
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <div className="w-2 h-2 rounded-full bg-emerald-500 mt-0.5" />
              <span>Translated:</span>
            </div>
            <Textarea
              placeholder="Translation will appear here..."
              className="min-h-[100px] resize-none bg-muted/50"
              value={translatedText}
              readOnly
            />
          </div>
        </div>
      </Card>
    </div>
  )
}

